const sampleStudents = [
  { name: "Aarav Sharma", attendance: 62, hours: 3, score: 42, status: "High Risk" },
  { name: "Diya Patel", attendance: 78, hours: 6, score: 58, status: "Needs Attention" },
  { name: "Rohan Das", attendance: 94, hours: 12, score: 88, status: "On Track" },
  { name: "Meera Singh", attendance: 86, hours: 9, score: 76, status: "On Track" },
  { name: "Kabir Khan", attendance: 69, hours: 4, score: 49, status: "High Risk" },
  { name: "Ananya Roy", attendance: 82, hours: 7, score: 68, status: "Needs Attention" }
];

let students = [...sampleStudents];

const tableBody = document.getElementById("studentTable");
const searchInput = document.getElementById("searchInput");
const riskFilter = document.getElementById("riskFilter");
const csvInput = document.getElementById("csvInput");

function statusClass(status) {
  if (status === "High Risk") return "high";
  if (status === "Needs Attention") return "medium";
  return "good";
}

function renderStudents() {
  const search = searchInput.value.trim().toLowerCase();
  const filter = riskFilter.value;
  const filtered = students.filter(student => {
    const matchesSearch = String(student.name || "").toLowerCase().includes(search);
    const matchesFilter = filter === "all" || student.status === filter;
    return matchesSearch && matchesFilter;
  });

  tableBody.innerHTML = "";
  if (!filtered.length) {
    tableBody.innerHTML = '<tr><td colspan="5">No matching records found.</td></tr>';
  } else {
    filtered.forEach(student => {
      const row = document.createElement("tr");
      [student.name, `${student.attendance}%`, student.hours, student.score].forEach(value => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
      const statusCell = document.createElement("td");
      const badge = document.createElement("span");
      badge.className = `status ${statusClass(student.status)}`;
      badge.textContent = student.status;
      statusCell.appendChild(badge);
      row.appendChild(statusCell);
      tableBody.appendChild(row);
    });
  }
  document.getElementById("recordCount").textContent =
    `Showing ${filtered.length} of ${students.length} records`;
}

function parseCSVLine(line) {
  // Basic CSV parser for simple comma-separated files; quoted commas are not supported.
  return line.split(",").map(value => value.trim().replace(/^"|"$/g, ""));
}

csvInput.addEventListener("change", async event => {
  const file = event.target.files[0];
  if (!file) return;
  const text = await file.text();
  const lines = text.split(/\r?\n/).filter(line => line.trim());
  if (lines.length < 2) {
    alert("The selected CSV does not contain data rows.");
    return;
  }

  const headers = parseCSVLine(lines[0]).map(header => header.toLowerCase());
  const findColumn = candidates => headers.findIndex(header => candidates.includes(header));
  const nameIndex = findColumn(["student_name", "name", "student id", "student_id"]);
  const attendanceIndex = findColumn(["attendance", "attendance_percentage", "attendance rate"]);
  const hoursIndex = findColumn(["hours_studied", "study_hours", "study hours"]);
  const scoreIndex = findColumn(["exam_score", "score", "final_score"]);

  if (scoreIndex < 0) {
    alert("CSV uploaded, but no Exam_Score / score column was found. Please check the column names.");
    return;
  }

  const imported = lines.slice(1).map((line, index) => {
    const cells = parseCSVLine(line);
    const score = Number(cells[scoreIndex]);
    const attendance = attendanceIndex >= 0 ? Number(cells[attendanceIndex]) : 0;
    const hours = hoursIndex >= 0 ? Number(cells[hoursIndex]) : 0;
    const name = nameIndex >= 0 ? cells[nameIndex] : `Student ${index + 1}`;
    const status = score < 50 || attendance < 65 ? "High Risk"
      : score < 70 || attendance < 75 ? "Needs Attention" : "On Track";
    return { name, attendance: Number.isFinite(attendance) ? attendance : 0,
      hours: Number.isFinite(hours) ? hours : 0, score, status };
  }).filter(student => Number.isFinite(student.score));

  if (!imported.length) {
    alert("No valid score values were found in the CSV.");
    return;
  }

  students = imported;
  renderStudents();
  const average = students.reduce((sum, student) => sum + student.score, 0) / students.length;
  const attendanceValues = students.map(student => student.attendance).filter(Number.isFinite);
  const attendanceAverage = attendanceValues.length
    ? attendanceValues.reduce((sum, value) => sum + value, 0) / attendanceValues.length : 0;
  document.getElementById("totalStudents").textContent = students.length.toLocaleString();
  document.getElementById("averageScore").textContent = average.toFixed(1);
  document.getElementById("riskCount").textContent =
    students.filter(student => student.status !== "On Track").length.toLocaleString();
  document.getElementById("attendanceAverage").textContent = `${attendanceAverage.toFixed(0)}%`;
  document.getElementById("dataNotice").innerHTML =
    `<strong>CSV preview loaded:</strong> ${file.name} (${students.length.toLocaleString()} rows parsed). Status labels are simple demo rules, not predictions from your trained ML model.`;
});

searchInput.addEventListener("input", renderStudents);
riskFilter.addEventListener("change", renderStudents);

document.getElementById("todayLabel").textContent =
  new Date().toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

renderStudents();
