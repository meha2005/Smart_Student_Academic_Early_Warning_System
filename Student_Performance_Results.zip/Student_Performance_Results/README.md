# Student Performance Prediction — Results

This folder contains evaluation outputs generated from `StudentPerformanceFactors.csv`.

## Model
- Random Forest Regression
- Target: `Exam_Score`
- Train/test split: 80% / 20%
- Random state: 42
- Trees: 300
- Numeric missing values: median imputation
- Categorical missing values: most-frequent imputation + one-hot encoding

## Files
- `model_results.csv`: model configuration and headline metrics
- `performance_metrics.csv`: MAE, RMSE, R², and split sizes
- `prediction_results.csv`: actual and predicted scores for the held-out test set
- `feature_importance.csv`: feature importance values
- `feature_importance.png`: top 15 feature importance chart
- `actual_vs_predicted.png`: test-set prediction plot
- `RESULTS_SUMMARY.txt`: plain-text summary

## Metric interpretation
- MAE and RMSE are prediction-error measures; lower is better.
- R² measures the proportion of target variance explained by the model; closer to 1 is generally better.
- Feature importance is not evidence of causation.
